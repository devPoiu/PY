import sys
from PyQt6 import QtCore
from PyQt6.QtWidgets import QApplication, QLabel, QPushButton, \
    QHBoxLayout, QVBoxLayout, QDoubleSpinBox, QTableWidget, QTableWidgetItem, QDialog
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt


# создание процесса для графического интерфейса
app = QApplication(sys.argv)

# создание окна программы
form = QDialog()

# заголовок окна
form.setWindowTitle("График функции ряда")

# создание меток
form.X_label = QLabel('Начальное значение:', form)
form.Xe_label = QLabel('Конечное значение:', form)
form.S_label = QLabel('Шаг:', form)
form.T_label = QLabel('Значение А:', form)

# Создание коробки ввода
form.X = QDoubleSpinBox(form)

# минимальное значение
form.X.setMinimum(-100.0)

# максимальное значение
form.X.setMaximum(9.0)

# шаг изменения
form.X.setSingleStep(1.0)

# значение по умолчанию
form.X.setProperty("value", 0)
form.Xe = QDoubleSpinBox(form)
form.Xe.setMinimum(-100.0)
form.Xe.setProperty("value", 2)
form.Step = QDoubleSpinBox(form)
form.Step.setMinimum(0.000000001)
form.Step.setProperty("value", 0.05)
form.A = QDoubleSpinBox(form)
form.A.setProperty("value", 10)

#создание кнопок
form.pushButtonResult = QPushButton('Результат', form)
form.Clear = QPushButton('Очистить', form)

#создание таблиц
form.tableWidget = QTableWidget(form)

# задание минимальных размеров таблицы
form.tableWidget.setMinimumSize(QtCore.QSize(400, 500))

# количество столбиков
form.tableWidget.setColumnCount(2)

# создастся экземпляр столбик (первый столбик), благодаря этому - не просто картинка,
# он обладает рядом возможностей
item = QTableWidgetItem()
form.tableWidget.setHorizontalHeaderItem(0, item)

# ширина первого(0) столбика
form.tableWidget.setColumnWidth(0, 100)

# заголовок столбика
item.setText("X")

# второй столбик
item = QTableWidgetItem()
form.tableWidget.setHorizontalHeaderItem(1, item)
form.tableWidget.setColumnWidth(1, 190)
item.setText("Y")

# экземпляр фигуры для построения графика
form.figure = plt.figure()

# виджет Canvas, который отображает `рисунок`
# он принимает экземпляр `figure` в качестве параметра для конструктора
form.canvas = FigureCanvas(form.figure)

# это навигационный виджет
# для этого требуется виджет Canvas и родительский элемент
form.toolbar = NavigationToolbar(form.canvas, form)

# группировка объектов для их отображения, нет необходимости каждый объект выставлять
# на форме. Очень ускоряет ручное создание интерфейса
# горизонтальная группа
form.label_h_layout = QHBoxLayout() # 1
form.line_h_layout = QHBoxLayout() # 2
form.button_h_layout = QHBoxLayout() # 3
form.Tlayout = QHBoxLayout()

# вертикальная группа
form.label_line_v_layout = QVBoxLayout() # 4
form.all_v_layout = QVBoxLayout() # 5
form.layout = QVBoxLayout()# 7

#добавление виджетов в группу, например, выстраиваем метки как на рисуноке 5
form.label_h_layout.addWidget(form.X_label)
form.label_h_layout.addWidget(form.X)
form.label_h_layout.addWidget(form.Xe_label)
form.label_h_layout.addWidget(form.Xe)
form.line_h_layout.addWidget(form.S_label)
form.line_h_layout.addWidget(form.Step)
form.line_h_layout.addWidget(form.T_label)
form.line_h_layout.addWidget(form.A)

# группа кнопок, в отличии от верхних виджетов, которых 4 в ряд, кнопок 2 и их
# растянет, что создаст более гармоничный интерфейс, но если это не устраивает, то
# задайте объекту минимальные/максимальные размеры.
form.button_h_layout.addWidget(form.pushButtonResult)
form.button_h_layout.addWidget(form.Clear)

#навигационная панель одна она растянется на все окно
form.layout.addWidget(form.toolbar)

# обратите внимание порядок добавление в группу имеет значение!!!
form.Tlayout.addWidget(form.tableWidget)
form.Tlayout.addWidget(form.canvas)

# позволяет определить каким образом группы в итоге будут расположены на окне. Порядок
# написания команд имеет значение!!!
form.label_line_v_layout.addLayout(form.label_h_layout)
form.label_line_v_layout.addLayout(form.line_h_layout)
form.all_v_layout.addLayout(form.label_line_v_layout)
form.all_v_layout.addLayout(form.button_h_layout)
form.all_v_layout.addLayout(form.layout)
form.all_v_layout.addLayout(form.Tlayout)

#устанавливает группы на форму.
form.setLayout(form.all_v_layout)

# кнопка очистить
def clear():
    form.X.clear()
    form.A.clear()
    form.Step.clear()
    form.Xe.clear()
    form.figure.clear()
    form.tableWidget.clear()
    item = QTableWidgetItem()
    form.tableWidget.setHorizontalHeaderItem(0, item)
    item.setText("X")
    item = QTableWidgetItem()
    form.tableWidget.setHorizontalHeaderItem(1, item)
    item.setText("Y")
    
# кнопка рисования графика
def plot():
    start = form.X.value()
    finish = float(form.Xe.text().replace(",", "."))
    step = float(form.Step.text().replace(",", "."))
    a = float(form.A.text().replace(",", "."))
    
    # координаты x и yy
    x = []
    yy = []
    
    while start <= finish:
        x += [start]
        y = a **(-start) - a **(-a * start) 
        yy += [y]
        start += step
        
    # заполнение таблицы
    form.tableWidget.setRowCount(len(x))
    for row in range(len(x)):
        form.tableWidget.setItem(row, 0, QTableWidgetItem(str(x[row])))
        form.tableWidget.setItem(row, 1, QTableWidgetItem(str(yy[row])))
        
    # рисование графика
    form.figure.clear()
    ax = form.figure.add_subplot(111)
    ax.plot(x,yy, marker = '.')
    form.canvas.draw()
    
form.pushButtonResult.clicked.connect(plot)
form.Clear.clicked.connect(clear)

form.show()
sys.exit(app.exec())