import sys
from PyQt6 import QtWidgets
from PyQt6.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView
from PyQt6.QtCore import Qt
from ui import Ui_Form
import csv



class Student:
    def __init__(self, fio, score, group, amount):
        self.fio = fio
        self.score = float(score)
        self.group = group
        self.amount = float(amount)

    def __str__(self):
        return f'{self.no} {self.fio} {self.score} {self.group} {self.amount}'
    
    def info(self):
        return [self.fio, self.score, self.group, self.amount]

def importCSV(file):
    students = []
    with open(file, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            student = Student(fio = row['FIO'], 
                              score = row['Score'],
                              group = row['Group'],
                              amount = row['Amount'],)
            students.append(student)
    return students

students = importCSV('students.csv')

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
ui = Ui_Form()
ui.setupUi(Form)

def addRow():
    rows = ui.tableWidget.rowCount()
    ui.tableWidget.insertRow(rows)

def delRow():
    row = ui.tableWidget.currentRow()
    if row > -1:
        ui.tableWidget.removeRow(row)
    ui.tableWidget.selectionModel().clearCurrentIndex()

def upData():
    item = ui.tableWidget.currentItem()
    if item:
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
        ui.tableWidget.editItem(item)



header = ["ФИО", "Успеваемость", "Группа", "Стипендия"]
colums = len(header)

ui.tableWidget.setColumnCount(colums)
ui.tableWidget.setHorizontalHeaderLabels(header)
ui.tableWidget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
ui.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

for i, student in enumerate(students):
    addRow()
    for j in range(len(student.info())):
        item = QTableWidgetItem(str(student.info()[j]))
        ui.tableWidget.setItem(i, j, item)

ui.change.clicked.connect(upData)
ui.add.clicked.connect(addRow)
ui.deletee.clicked.connect(delRow)
ui.close.clicked.connect(Form.close)
ui.tableWidget.selectionModel().clearCurrentIndex()

Form.show()
sys.exit(app.exec())