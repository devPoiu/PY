import csv

class Student:
    def __init__(self, no, fio, score, group, amount):
        self.no = no
        self.fio = fio
        self.score = float(score)
        self.group = group
        self.amount = float(amount)

    def __str__(self):
        return f'{self.no} {self.fio} {self.score} {self.group} {self.amount}'

def importCSV(file):
    students = []
    with open(file, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            student = Student(no = row['No'], 
                              fio = row['FIO'], 
                              score = row['Score'],
                              group = row['Group'],
                              amount = row['Amount'],)
            students.append(student)
    return students

students = importCSV('students.csv')

for student in students:
    print(student)