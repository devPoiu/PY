from numpy import arange, sin, cos
from matplotlib.pyplot import plot, show, legend, xlabel, ylabel, title, figure

# создание массива на интервале: начало, конец, шаг с которым меняется х
x = arange(-10, 10.01, 0.1)

# создание окна
fig = figure()

# Надпись в заголовке окна
fig.canvas.setWindowTitle('График функции')

# значение/массив значений х, функция изменения y или массив НО если
# массив количество элементов х и y должно быть одинаково
plot(x, sin(x), label="Синусоида")
plot(x, cos(x), label=r"$f_2(x) =\cos(x)$" )

# подпись осей х и y
xlabel(r"$x$" , fontsize = 14)
ylabel(r'$f(x)$' , fontsize = 14)

# формат отображения легенды (надписей)
legend(loc='best', fontsize = 12)

# подпись графика
title("Отображение sin и cos")

show()