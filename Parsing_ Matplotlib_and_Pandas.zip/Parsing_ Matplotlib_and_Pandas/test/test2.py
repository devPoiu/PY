from random import randint
from numpy import arange, sin, cos
from matplotlib.pyplot import plot, show, legend, xlabel, ylabel, hist, title
from pylab import subplot
def graf():
    # количество строк, количество столбцов, номер ячейки
    subplot(1, 2, 1)
    # интервал начало, конец, шаг с которым меняется х
    x = arange(-10, 10.01, 0.1)
    title("первый вариант")
    # значение/массив значений х, функция изменения y или массив НО если массив количество элементов х и y должно быть одинаково
    plot(x, sin(x), label="$Синусоида$")
    plot(x, cos(x), label=r'$f_2(x) =\cos(x)$' )
    # подпись осей х и y
    xlabel(r'$x$' , fontsize = 14)
    ylabel(r'$f(x)$', fontsize = 14)
    legend(loc= 'best' , fontsize = 12)
def diagram():
    # количество строк, количество столбцов, номер ячейки
    subplot(1, 2, 2)
    dataset = ([randint(-10, 100) for _ in range(10)])
    hist(dataset)
    title("Гистограмма значений")
graf()
diagram()
show()