i,fio, *avg, group, amount = [1,2, 'ewr',3,4,23] 
print(i,fio, avg, group, amount)