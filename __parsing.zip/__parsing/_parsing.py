from bs4 import BeautifulSoup
import requests
import json
from _parsingTables import parsingPDF
import re
import os


# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# !!!!!!!!!!!!   запускать этот файл   !!!!!!!!!!!!!!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


url = 'https://www.rpatyphoon.ru/products/pollution-media.php'
response = requests.get(url, timeout=10)
soup = BeautifulSoup(response.text, 'html.parser')

list = []
for row in soup.find_all("a"):
    href = row.get('href')
    if re.search(r'\d{2}_\d{4}', href) or re.search(r'\d{4}_\d{2}', href):
        list.append({
            'url': f'https://www.rpatyphoon.ru{row.get('href')}',
            'file': row.get('title')[-11:-4]
        })

with open('pdf_url.json', 'w', encoding='utf-8') as f:
    json.dump(list, f, ensure_ascii=False, indent=4)

os.makedirs('csv', exist_ok=True)

# path = r'C:\Users\BRICS_208\Documents\411\4 semestr\py\parsing\csv'           # УКАЗАТЬ папку CSV
path = r'D:\Ycheb\2course\4semestr\py\_______parsing\csv'                     # УКАЗАТЬ папку CSV

files = os.listdir(path)
strFiles = ' '.join(files)
# print(strFiles)

for index, obj in enumerate(list):
    air_file = obj['file'] + '_air.csv'
    month_file = obj['file'] + '_month.csv'
    if air_file not in strFiles or month_file not in strFiles:
        print(obj['url'])
        parsingPDF(obj['url'])
        # if index == 2: break


# parsingPDF(list[-1]['url'])

# parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/bul_rorf_12_2025.pdf')