from bs4 import BeautifulSoup
import requests, pdfplumber
import pandas as pd
import re
import threading
import sys
import time
import os
import psycopg2
from sqlalchemy import create_engine

def _print(message):
    sys.stdout.write(f"\r\033[K{message}\n")
    sys.stdout.flush()

def parsingPDF(url):

    def animate():
        chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        while not done:
            for char in chars:
                sys.stdout.write(f"\r{char}  ")
                sys.stdout.flush()
                time.sleep(0.005)
                if done: break
    
    done = False
    t = threading.Thread(target=animate)
    t.start()

    try:

        namePDF = url.split('/')[-1]
        name = namePDF[-11:-4]


        response = requests.get(url, timeout= 10)

        if response.status_code == 200:
            with open(namePDF, "wb") as f:
                f.write(response.content)
            _print(f"PDF сохранён: {namePDF}, размер {len(response.content)} байт")
        else: raise ValueError(f"Ошибка загрузки: {response.status_code}")

        tab = 0
        all_data1 = []
        all_data2 = []
        with pdfplumber.open(namePDF) as pdf:
            for page in pdf.pages:
                    text = page.extract_text() or ''
                    tables = page.extract_tables()
                    for table in tables:
                        if re.search(r'данным телеграмм .месяц.' , text, re.IGNORECASE):
                            tab = 1
                        if tab == 1:
                            if table and len(table):
                                all_data1.extend(table)

                        if re.search(r'данным телеграмм .воздух.', text, re.IGNORECASE):
                            tab = 2
                        if tab == 2:
                            if table and len(table):
                                all_data2.extend(table)

        # print(all_data1)
        # print(all_data2)

        # for data in all_data2:
        #     print(data)
        
        if all_data1 == [] or all_data2 == []:
            _print(f'!!!!!!!!! ------------------> Пропуск {name}')
            if os.path.exists(namePDF):
                os.remove(namePDF)
                _print(f"Файл {namePDF} удален")
            else:
                _print(f"Файл не найден")
            return
        
        # # Снять ограничение на количество строк
        pd.set_option('display.max_rows', None)
        # # Снять ограничение на количество столбцов
        # pd.set_option('display.max_columns', None)

        df1 = pd.DataFrame(all_data1)
        df1.iloc[:, 0] = df1.iloc[:, 0].astype(str).str.replace(r'\.$', '', regex=True)
        df1 = df1[df1[0].str.isdigit()]
        df1.iloc[:, 1] = df1.iloc[:, 1].astype(str).str.replace(r'\n', '', regex=True)
        ones = df1[df1[0].astype(str) == '1'].index
        if len(ones) >= 2:
            targeе = ones[1]
            pos = df1.index.get_loc(targeе)
            df1 = df1.iloc[:pos]
        df1 = df1.iloc[:, :14]
        del df1[0]
        del df1[12]
        headers = [ 'name',
                    'id',
                    'latitude',
                    'longitude',
                    'date_1',
                    'days_do_izmerenia_1' ,
                    'max_znachen_1' ,
                    'average_value_1',
                    'date_2' ,
                    'days_do_izmerenia_2' ,
                    'max_znachen_1' ,
                    'average_value_1']
        df1.columns = headers
        for i in df1.iloc:
            print(i['name'], i['id'], i['latitude'], i['longitude'])
        # _print(df1)


        engine = create_engine('postgresql://postgres:12345@localhost:5432/411Typhoon')
        df1[['id', 'name', 'latitude', 'longitude']].to_sql('city',
                   engine, 
                   if_exists='append', 
                   index=False, 
                   method='multi', 
                   chunksize=1000
        )



    # ================================================================================

        # df2 = pd.DataFrame(all_data2)
        # df2.iloc[:, 0] = df2.iloc[:, 0].astype(str).str.replace(r'\.$', '', regex=True)
        # df2 = df2[df2[0].str.isdigit()]
        # df2.iloc[:, 1] = df2.iloc[:, 1].astype(str).str.replace(r'\n', '', regex=True)
        # first = df2[df2[0].astype(str) == '1'].index
        # if not first.empty:
        #     df2 = df2.loc[first[0]:]
        # df2 = df2.iloc[:, :16]
        # # _print(df2)




        # if os.path.exists(namePDF):
        #     os.remove(namePDF)
        #     _print(f"Файл {namePDF} удален\n")
        # else:
        #     _print(f"Файл не найден\n")

    finally:

        done = True
        t.join()
                


if __name__=="__main__":
    parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2024.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_12_2016.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2025.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_05_2023.pdf')                  ##    пандас не видит текст
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_09_2023.pdf')                  ##    в таблице воздух 14 столбцов, а не 16
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/spravka_05_2013.pdf')