import psycopg2
import pandas as pd


def creatDATA():
    conn = psycopg2.connect(
        dbname= "postgres",
        user= "postgres",
        password= "12345",
    )
    cursor = conn.cursor()
    conn.autocommit=True
    cursor.execute("SELECT 1 FROM pg_database WHERE datname = '411Typhoon'")
    exists = cursor.fetchone()

    if not exists:
        cursor.execute('CREATE DATABASE "411Typhoon"')
        print("База создана")
    else:
        print("База уже существует")
    cursor.close()
    conn.close()

    conn = psycopg2.connect(
        dbname= "411Typhoon",
        user= "postgres",
        password= "12345",
    )
    cursor = conn.cursor()


    create_table = ['''
    CREATE TABLE IF NOT EXISTS city (
        id SERIAL PRIMARY KEY,
        name VARCHAR(50),
        latitude numeric(4,2),
        longitude numeric(4,2)
    );
    ''',
    '''
    CREATE TABLE IF NOT EXISTS month_data_1 (
        id SERIAL PRIMARY KEY,
        date VARCHAR(6),
        days_do_izmerenia integer,
        max_znachen numeric(4,2),
        average_value numeric(4,2)
    );
    ''',
    '''
    CREATE TABLE IF NOT EXISTS month_data_2 (
        id SERIAL PRIMARY KEY,
        date VARCHAR(6),
        days_do_izmerenia integer,
        max_znachen numeric(4,2),
        average_value numeric(4,2)
    );
    ''']


    conn_params = {
        "dbname": "411Typhoon",
        "user": "postgres",
        "password": "12345",
    }

    def creat(sql):
        with psycopg2.connect(**conn_params)as conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            print('успешно')

    for i in range(len(create_table)):
        creat(create_table[i])


    cursor.close()
    conn.close()

def insert():
    conn = psycopg2.connect(
        dbname= "postgres",
        user= "postgres",
        password= "12345",
    )
    cursor = conn.cursor()

    
    
    cursor.close()
    conn.close()


if __name__=="__main__":
   creatDATA()