import pandas as pd
import psycopg2
from sqlalchemy import create_engine

def create_db():
    conn = psycopg2.connect(
        dbname="411mig",
        user="postgres",
        password="12345",
        host="localhost",
        port="5432"
    )
    
    create_tables = [
        '''create table IF NOT EXISTS adres  (
            id serial primary key,
            index integer not null,
            city VARCHAR(255) NOT NULL,
            street VARCHAR(255) NOT NULL,
            dom VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS users  (
            id SERIAL PRIMARY KEY,
            rol VARCHAR(30) NOT NULL,
            FIO VARCHAR(30) NOT NULL,
            login VARCHAR(30) NOT NULL,
            password VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS tovar (
            id VARCHAR(6) PRIMARY KEY,
            name VARCHAR(30) NOT NULL,
            ed_iz VARCHAR(30) NOT NULL,
            cost VARCHAR(30) NOT NULL,
            postav VARCHAR(30) NOT NULL,
            proizv VARCHAR(30) NOT NULL,
            categoria VARCHAR(30) NOT NULL,
            discount VARCHAR(30) NOT NULL,
            kol VARCHAR(30) NOT NULL,
            opis VARCHAR(255) NOT NULL,
            foto VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS status (
            id serial primary key,
            stat VARCHAR(30) NOT NULL UNIQUE
        )''',
        '''CREATE TABLE zakaz (
            id SERIAL PRIMARY KEY,
            data_zakaz DATE,
            data_dost DATE,
            adres INT REFERENCES adres(id),
            user_id INT REFERENCES users(id) ON DELETE SET NULL,
            kod INT,
            status INT REFERENCES status(id)
        );''',
        '''CREATE TABLE IF NOT EXISTS zakaz_tovar (
            id SERIAL PRIMARY KEY,
            id_zakaz INTEGER REFERENCES zakaz(id) ON DELETE CASCADE,
            id_tovar VARCHAR(6) REFERENCES tovar(id) NOT NULL,
            kol INTEGER NOT NULL
        )''',
    ]

    
    conn.autocommit = True
    
    cur = conn.cursor()
    try:
        for i in create_tables:
            cur.execute(i)
    except Exception as e:
        print(e)
    cur.close()

    conn.close()