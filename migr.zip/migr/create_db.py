import pandas as pd
import psycopg2
from sqlalchemy import create_engine

def create_db():
    conn = psycopg2.connect(
        dbname="411mig",
        user="postgres",
        password="12345",
        host="localhost",
        port="5432"
    )
    
    create_tables = [
        '''create table IF NOT EXISTS adres  (
            index integer primary key,
            city VARCHAR(255) NOT NULL,
            street VARCHAR(255) NOT NULL,
            dom VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS users  (
            id SERIAL PRIMARY KEY,
            rol VARCHAR(30) NOT NULL,
            FIO VARCHAR(30) NOT NULL,
            login VARCHAR(30) NOT NULL,
            password VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS tovar (
            id VARCHAR(6) PRIMARY KEY,
            name VARCHAR(30) NOT NULL,
            ed_iz VARCHAR(30) NOT NULL,
            cost VARCHAR(30) NOT NULL,
            postav VARCHAR(30) NOT NULL,
            proizv VARCHAR(30) NOT NULL,
            categoria VARCHAR(30) NOT NULL,
            discount VARCHAR(30) NOT NULL,
            kol VARCHAR(30) NOT NULL,
            opis VARCHAR(255) NOT NULL,
            foto VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS status (
            id serial primary key,
            stat VARCHAR(30) NOT NULL
        )''',
        '''create table IF NOT EXISTS zakaz_tovar (
            id SERIAL PRIMARY KEY,
            id_tovar VARCHAR(6) REFERENCES tovar(id) not null,
            kol integer not null
        )''',
        '''create table IF NOT EXISTS zakaz  (
            id SERIAL PRIMARY KEY,
            zakaz_tovar integer REFERENCES zakaz_tovar(id),
            data_zakaz date not null,
            data_dost date not null,
            adres integer REFERENCES adres(index),
            FIO VARCHAR(30) NOT NULL,
            kod integer not null,
            status integer REFERENCES status(id)
        )''',
    ]

    
    conn.autocommit = True
    
    cur = conn.cursor()
    try:
        for i in create_tables:
            cur.execute(i)
    except Exception as e:
        print(e)
    cur.close()

    conn.close()