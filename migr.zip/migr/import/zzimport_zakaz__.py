import pandas as pd
import psycopg2
from datetime import datetime

DB_CONFIG = {
    "dbname": "411mig",
    "user": "postgres",
    "password": "12345",
    "host": "localhost",
    "port": "5432"
}

EXCEL_FILE = 'import/Заказ_import.xlsx' 

def zakaz():
    df = pd.read_excel(EXCEL_FILE, dtype={
        'Адрес пункта выдачи': int,
        'Код для получения': int,
        'Артикул заказа': str
    })
    
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    try:
        status_names = df['Статус заказа'].str.strip().unique()
        
        insertStatus = ''' 
            INSERT INTO status (stat)
            VALUES (%s) RETURNING id;
        '''

        status_mapping = {}
        for stat in status_names:
            cursor.execute(insertStatus, [stat])
            status_id = cursor.fetchone()[0]
            status_mapping[stat] = status_id

        # --- ШАГ 2: Построчный импорт заказов ---
        for index, row in df.iterrows():
            status_text = row['Статус заказа'].strip()
            status_id = status_mapping[status_text]
            
            # Безопасное преобразование дат
            date_zakaz = pd.to_datetime(row['Дата заказа']).date()
            date_dost = pd.to_datetime(row['Дата доставки']).date()
            
            insert_zakaz_query = """
            INSERT INTO zakaz (data_zakaz, data_dost, adres, FIO, kod, status)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id;
            """
            
            cursor.execute(insert_zakaz_query, (
                date_zakaz,
                date_dost,
                int(row['Адрес пункта выдачи']),
                row['ФИО авторизированного клиента'].strip(),
                int(row['Код для получения']),
                status_id
            ))
            
            zakaz_id = cursor.fetchone()[0]
            
            items = [item.strip() for item in str(row['Артикул заказа']).split(',')]
            
            for i in range(0, len(items), 2):                    
                id_tovar = items[i]
                kol = int(items[i+1])
                
                insert_tovar_query = """
                INSERT INTO zakaz_tovar (id_zakaz, id_tovar, kol)
                VALUES (%s, %s, %s);
                """
                cursor.execute(insert_tovar_query, (zakaz_id, id_tovar, kol))
        
        conn.commit()
        print("Таблица 'zakaz' успешно")
        
    except Exception as e:
        conn.rollback()
        print(f"Ошибка при импорте: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    zakaz()
