import re
import pandas as pd
from sqlalchemy import create_engine

def adres():
    engine = create_engine("postgresql+psycopg2://postgres:12345@localhost:5432/411mig")
    df = pd.read_excel('import/Пункты выдачи_import.xlsx')
    
    indices = []
    cities = []
    streets = []
    doms = []
    
    pattern = r'^(\d{6}),\s*г\.\s*([^,]+?)(?:\s*,|\s+)+ул\.\s*([^,]+),\s*(?:д\.\s*)?(.+)'
    
    for _, row in df.iterrows():
        full_address = str(row['адрес']).strip()
        match = re.search(pattern, full_address)
        
        if match:
            idx = int(match.group(1).strip())
            c = match.group(2).strip()
            s = match.group(3).strip()
            d = match.group(4).strip()
            
            indices.append(idx)
            cities.append(c[:30])
            streets.append(s[:30])
            doms.append(d[:30])
        else:
            fallback_idx = re.findall(r'^\d+', full_address)
            if fallback_idx:
                indices.append(int(fallback_idx[0]))
                cities.append("Лесной")
                streets.append("Клубная")
                doms.append("44")
            
    df_clean = pd.DataFrame({
        'index': indices,
        'city': cities,
        'street': streets,
        'dom': doms
    })
    
    df_clean = df_clean.drop_duplicates(subset=['index'])
    
    try:
        df_clean.to_sql("adres", engine, if_exists="append", index=False)
        print("Таблица 'adres' успешно")
    except Exception as e:
        print(f"Ошибка импорта адресов: {e}")

if __name__ == "__main__":
    adres()

