import pandas as pd
from sqlalchemy import create_engine


def otdacha():
    engine = create_engine('postgresql://postgres:12345@localhost:5432/411mig')

    df = pd.read_excel('import/Пункты выдачи_import.xlsx')

    df.to_sql('otdacha', engine, if_exists='replace', index=False)

    print("otdacha импортированы")

