import pandas as pd
from sqlalchemy import create_engine


def tovar():
    engine = create_engine("postgresql+psycopg2://postgres:12345@localhost:5432/411mig")
    
    df = pd.read_excel("import/tovar.xlsx")
    
    df = df.rename(columns={
        "Артикул": "id",
        "Наименование товара": "name",
        "Единица измерения": "ed_iz",
        "Цена": "cost",
        "Поставщик": "postav",
        "Производитель": "proizv",
        "Категория товара": "categoria",
        "Действующая скидка": "discount",
        "Кол-во на складе": "kol",
        "Описание товара": "opis",
        "Фото": "foto"
    })
    
    df = df[["id", "name", "ed_iz", "cost", "postav", "proizv", "categoria", "discount", "kol", "opis", "foto"]]
    
    df = df.drop_duplicates(subset=["id"])
    
    string_columns = ["id", "name", "ed_iz", "cost", "postav", "proizv", "categoria", "discount", "kol", "opis", "foto"]
    for col in string_columns:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()
            
    try:
        df.to_sql("tovar", engine, if_exists="append", index=False)
        print("Таблица 'tovar' успешно")
    except Exception as e:
        print(f"Ошибка при импорте товаров в БД: {e}")

if __name__ == "__main__":
    tovar()
