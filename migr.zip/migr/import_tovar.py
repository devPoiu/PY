import pandas as pd
from sqlalchemy import create_engine


def tovar():
    engine = create_engine('postgresql://postgres:12345@localhost:5432/411mig')

    df = pd.read_excel('import/Tovar.xlsx')

    df.to_sql('tovar', engine, if_exists='replace', index=False)

    print("tovar импортирован")

