import pandas as pd
from sqlalchemy import create_engine


def users():
    engine = create_engine('postgresql://postgres:12345@localhost:5432/411mig')

    df = pd.read_excel('import/user_import.xlsx')

    df.to_sql('users', engine, if_exists='replace', index=False)

    print("users импортированы")

