

import pandas as pd
from sqlalchemy import create_engine

def users():
    engine = create_engine("postgresql+psycopg2://postgres:12345@localhost:5432/411mig")
    
    df = pd.read_excel('import/user_import.xlsx')
    
    df = df.rename(columns={
        "Роль сотрудника": "rol",
        "ФИО": "fio",
        "Логин": "login",
        "Пароль": "password"
    })
    
    df = df[["rol", "fio", "login", "password"]]
    
    for col in df.columns:
        df[col] = df[col].astype(str).str.strip()
        
    df = df.drop_duplicates(subset=["login"])
    
    try:
        df.to_sql("users", engine, if_exists="append", index=False)
        print("Таблица 'users' успешно")
    except Exception as e:
        print(f"Ошибка при импорте пользователей в БД: {e}")

if __name__ == "__main__":
    users()
