import pandas as pd
from sqlalchemy import create_engine


def zakaz():
    engine = create_engine('postgresql://postgres:12345@localhost:5432/411mig')

    df = pd.read_excel('import/Заказ_import.xlsx')

    df.to_sql('zakaz', engine, if_exists='replace', index=False)

    print("zakaz импортированы")

