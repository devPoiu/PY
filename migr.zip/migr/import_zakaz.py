# import pandas as pd
# from sqlalchemy import create_engine


# def zakaz():
#     engine = create_engine('postgresql://postgres:12345@localhost:5432/411mig')

#     df = pd.read_excel('import/Заказ_import.xlsx')

#     df.to_sql('zakaz', engine, if_exists='replace', index=False)

#     print("zakaz импортированы")


import pandas as pd
import psycopg2
from datetime import datetime



DB_CONFIG = {
    "dbname": "411mig",
    "user": "postgres",
    "password": "12345",
    "host": "localhost",
    "port": "5432"
}

EXCEL_FILE = 'import/Заказ_import.xlsx' 

def zakaz():
    df = pd.read_excel(EXCEL_FILE, dtype={
        'Адрес пункта выдачи': int,
        'Код для получения': int
    })
    
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    try:
        for index, row in df.iterrows():
            status_text = row['Статус заказа'].strip()
            status_id = 1 if status_text == 'Завершен' else 2
            
            date_zakaz = pd.to_datetime(row['Дата заказа']).date()
            date_dost = pd.to_datetime(row['Дата доставки']).date()
            
            insert_zakaz_query = """
            INSERT INTO zakaz (data_zakaz, data_dost, adres, FIO, kod, status)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id;
            """
            
            cursor.execute(insert_zakaz_query, (
                date_zakaz,
                date_dost,
                int(row['Адрес пункта выдачи']),
                row['ФИО авторизированного клиента'].strip(),
                int(row['Код для получения']),
                status_id
            ))
            
            zakaz_id = cursor.fetchone()[0]
            
            items = [item.strip() for item in row['Артикул заказа'].split(',')]
            
            for i in range(0, len(items), 2):
                id_tovar = items[i]
                kol = int(items[i+1])
                
                insert_tovar_query = """
                INSERT INTO zakaz_tovar (id_zakaz, id_tovar, kol)
                VALUES (%s, %s, %s);
                """
                cursor.execute(insert_tovar_query, (zakaz_id, id_tovar, kol))
        
        conn.commit()
        print("Данные успешно импортированы!")
        
    except Exception as e:
        conn.rollback()
        print(f"Ошибка при импорте: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    zakaz()


