import pandas as pd
import psycopg2
from import_user import users
from import_tovar import tovar
from import_zakaz import zakaz
from import_adres import adres
from create_db import create_db

conn = psycopg2.connect(
    dbname="postgres",
    user="postgres",
    password="12345",
    host="localhost",
    port="5432"
)


conn.autocommit = True

cur = conn.cursor()
try:
    cur.execute('CREATE DATABASE "411mig"')
except Exception:
    print('уже есть БД')
cur.close()

conn.close()

create_db()

# users()
# tovar()
# zakaz()
adres()
