
select * from adres;
select * from status;
select * from zakaz;
select * from zakaz_tovar;
select * from tovar;
select * from users;