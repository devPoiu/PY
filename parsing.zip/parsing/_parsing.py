from bs4 import BeautifulSoup
import requests
import json
from _parsingTables import parsingPDF
import re
import os


# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# !!!!!!!!!!!!   запускать этот файл   !!!!!!!!!!!!!!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


url = 'https://www.rpatyphoon.ru/products/pollution-media.php'
response = requests.get(url, timeout=10)
soup = BeautifulSoup(response.text, 'html.parser')

list = []
for row in soup.find_all("a"):
    href = row.get('href')
    if re.search(r'\d{2}_\d{4}', href) or re.search(r'\d{4}_\d{2}', href):
        list.append(
            f'https://www.rpatyphoon.ru{row.get('href')}'
        )
        
with open('pdf_url.json', 'w', encoding='utf-8') as f:
    json.dump(list, f, ensure_ascii=False, indent=4)

os.makedirs('csv', exist_ok=True)

path = r'D:\Ycheb\2course\4semestr\py\_______parsing\csv'   

files = os.listdir(path)
strFiles = ' '.join(files)

for index, obj in enumerate(list):
    air_file = obj['file'] + '_air.csv'
    month_file = obj['file'] + '_month.csv'
    if air_file not in strFiles or month_file not in strFiles:
        print(obj['url'])
        parsingPDF(obj['url'])
        # if index == 2: break