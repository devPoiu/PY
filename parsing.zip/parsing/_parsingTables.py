from bs4 import BeautifulSoup
import requests, pdfplumber
import pandas as pd
import re
import threading
import sys
import time
import os
import psycopg2
from sqlalchemy import create_engine

def parsingPDF(url):
    namePDF = url.split('/')[-1]
    
    # # 1. Загрузка файла
    # response = requests.get(url, timeout=15)
    # if response.status_code == 200:
    #     with open(namePDF, "wb") as f:
    #         f.write(response.content)
    #     print(f"PDF сохранён: {namePDF}")
    # else:
    #     print(f"Ошибка загрузки: {response.status_code}")
    #     return

    all_data1 = []
    all_data2 = []
    
    with pdfplumber.open(namePDF) as pdf:
        for page in pdf.pages:
            tables = page.extract_tables()
            for table in tables:
                if len(table[0]) == 14:
                    all_data1.extend(table)
                if len(table[0]) ==16:
                    all_data2.extend(table)

    if not all_data1:
        print(f"Данные в таблице 14 столбцов не найдены.")
        if os.path.exists(namePDF): os.remove(namePDF)
        return
    if not all_data2:
        print(f"Данные в таблице 16 столбцов не найдены.")
        if os.path.exists(namePDF): os.remove(namePDF)
        return

    # 3. Чистка данных без Pandas
    cleaned_data = []
    seen_one = False 
    
    for row in all_data1:
        # Проверка на пустую строку
        if not row or row[0] is None:
            continue

        # Очистка индекса (первая колонка)
        first_col = str(row[0]).strip().rstrip('.')
        
        # Логика остановки на второй таблице (если встретили '1' второй раз)
        if first_col == '1':
            if seen_one: 
                break
            seen_one = True
            
        # Оставляем только строки, где в начале число (ID города)
        if not first_col.isdigit():
            continue
            
        # Формируем словарь (аналог колонок в Pandas)
        # Мы берем индексы как в вашем коде: 1-11 и 13 (пропуская 0 и 12)
        try:
            new_row = {
                'n': row[0],
                'name': str(row[1]).replace('\n', ' '),
                'id': row[2],
                'latitude': row[3],
                'longitude': row[4],
                'date_1': row[5],
                'days_1': row[6],
                'max_1': row[7],
                'avg_1': row[8],
                'date_2': row[9],
                'days_2': row[10],
                'max_2': row[11], 
                'avg_2': row[13]
            }
            cleaned_data.append(new_row)
        except IndexError:
            continue

    # 4. Вывод результата
    print(f"{'n':<3}|{'Название':<25} | {'Lat':<8} | {'Lon':<8} | {'Max 1'}")
    print("-" * 60)
    for item in cleaned_data:
        print(f"{item['n']:<3}|{item['name'][:25]:<25} | {item['latitude']:<8} | {item['longitude']:<8} | {item['max_1']}")

    # # 5. Удаление файла
    # if os.path.exists(namePDF):
    #     os.remove(namePDF)
    #     print(f"\nФайл {namePDF} удален")


if __name__=="__main__":
    parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2024.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_12_2016.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2025.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_05_2023.pdf')                  ##    пандас не видит текст
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_09_2023.pdf')                  ##    в таблице воздух 14 столбцов, а не 16
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/spravka_05_2013.pdf')
        