from bs4 import BeautifulSoup
import requests
import json
from _parsingTables import parsingPDF
from _posgreSQL import createDB
import re
import asyncio
from concurrent.futures import ThreadPoolExecutor


# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# !!!!!!!!!!!!   запускать этот файл   !!!!!!!!!!!!!!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


url = 'https://www.rpatyphoon.ru/products/pollution-media.php'
response = requests.get(url, timeout=10)
soup = BeautifulSoup(response.text, 'html.parser')

createDB()

list = []
for row in soup.find_all("a"):
    href = row.get('href')
    if re.search(r'\d{2}_\d{4}', href) or re.search(r'\d{4}_\d{2}', href):
        list.append(
            f'https://www.rpatyphoon.ru{row.get('href')}'
        )
        
with open('pdf_url.json', 'w', encoding='utf-8') as f:
    json.dump(list, f, ensure_ascii=False, indent=4)

# for index, obj in enumerate(list):
#     print(obj)
#     parsingPDF(obj)
#     # if index == 13: break

async def process_pdf(executor, url):
    loop = asyncio.get_event_loop()
    print(f"Starting: {url}")
    await loop.run_in_executor(executor, parsingPDF, url)
    print(f"Finished: {url}")

async def main():
    with ThreadPoolExecutor(max_workers=5) as executor:
        tasks = []
        for obj in list:
            tasks.append(process_pdf(executor, obj))
        
        await asyncio.gather(*tasks)

if __name__ == '__main__':
    asyncio.run(main())