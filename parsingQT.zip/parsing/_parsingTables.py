from bs4 import BeautifulSoup
import requests, pdfplumber
import os
import psycopg2

def all_data(allData, date, cur):
    date = date.split('_')
    date[-1] = date[-1][0:4]
    if len(date[-1]) == 4:
        year = date[-1]
        month = date[-2]
    else:
        month = date[-1]
        year = date[-2]

    def nnull(pam):
        if pam == '' or pam == '-':
            return None
        else: 
            return pam

    match len(allData[0]):
        case 14:
            for row in allData:
                if not row or row[0] is None:
                    continue

                first_col = str(row[0]).strip().rstrip('.')
                    
                # Оставляем только строки, где в начале число
                if not first_col.isdigit():
                    continue
                    
                try:
                    
                    for i in range(len(row)):
                        row[i] = nnull(row[i])

                    city_query = """
                        INSERT INTO city (id, name, latitude, longitude) 
                        VALUES (%s, %s, %s, %s) 
                        ON CONFLICT (id) DO NOTHING;
                    """
                    cur.execute(city_query, (row[2], 
                                             str(row[1]).replace('\n', ' '),
                                             row[3],
                                             row[4]
                                             )
                    )

                    month_query = """
                        INSERT INTO month (id_city, date_1, days_1, max_1, avg_1, date_2, days_2, max_2, avg_2) 
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);
                    """
                    if row[5]:
                        day1 = row[5].split('-')[0]
                        day1 = f'{year}-{month}-{day1}'
                    else: 
                        day1 = None
                    if row[9]:
                        day2 = row[9].split('-')[0]
                        day2 = f'{year}-{month}-{day2}'
                    else: 
                        day2 = None

                    cur.execute(month_query, 
                        (
                            row[2],
                            day1,
                            row[6],
                            row[7],
                            row[8],
                            day2,
                            row[10],
                            row[11],
                            row[13]
                        )
                    )
                except IndexError:
                    continue


        case 16:
            for row in allData:
                if not row or row[0] is None:
                    continue

                first_col = str(row[0]).strip().rstrip('.')
                
                if not first_col.isdigit():
                    continue

                try:                    
                    for i in range(len(row)):
                        row[i] = nnull(row[i])

                    city_query = """
                        INSERT INTO city (id, name, latitude, longitude) 
                        VALUES (%s, %s, %s, %s) 
                        ON CONFLICT (id) DO NOTHING;
                    """
                    cur.execute(city_query, (row[2], 
                                             str(row[1]).replace('\n', ' '),
                                             row[3],
                                             row[4]
                                             )
                    )

                    air_query = """
                        INSERT INTO air (id_city, date_1, days_1, max_1, avg_1, measur_1, date_2, days_2, max_2, avg_2, measur_2) 
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                    """

                    if row[5]:
                        day1 = row[5].split('-')[0]
                        day1 = f'{year}-{month}-{day1}'
                    else: 
                        day1 = None
                    if row[10]:
                        day2 = row[10].split('-')[0]
                        day2 = f'{year}-{month}-{day2}'
                    else: 
                        day2 = None

                    cur.execute(air_query, (row[2],
                                            day1,
                                            row[6],
                                            row[7],
                                            row[8],
                                            row[9],
                                            day2,
                                            row[11],
                                            row[12],
                                            row[14],
                                            row[15]
                                            )
                    )
                except IndexError:
                    continue



def parsingPDF(url):
    match url:
        case 'https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_05_2023.pdf':
            return
        case 'https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_09_2023.pdf':
            return
    
    namePDF = url.split('/')[-1]
    
    response = requests.get(url, timeout=15)
    if response.status_code == 200:
        with open(namePDF, "wb") as f:
            f.write(response.content)
        print(f"PDF сохранён: {namePDF}")
    else:
        print(f"Ошибка загрузки: {response.status_code}")
        return

    all_data1 = []
    all_data2 = []
    
    with pdfplumber.open(namePDF) as pdf:
        for page in pdf.pages:
            tables = page.extract_tables()
            for table in tables:
                if len(table[0]) == 14:
                    all_data1.extend(table)
                if len(table[0]) == 16:
                    all_data2.extend(table)

    if not all_data1:
        print(f"Данные в таблице 14 столбцов не найдены.")
        if os.path.exists(namePDF): os.remove(namePDF)
        return
    if not all_data2:
        print(f"Данные в таблице 16 столбцов не найдены.")
        if os.path.exists(namePDF): os.remove(namePDF)
        return

    db_params = {
        "host": "localhost",
        "database": "typhoon_411", 
        "user": "postgres",
        "password": "12345"
    }
    with psycopg2.connect(**db_params) as conn:
            with conn.cursor() as cur:
                all_data(all_data1, namePDF, cur)
                all_data(all_data2, namePDF, cur)

    conn.commit()

    if os.path.exists(namePDF):
        os.remove(namePDF)
        print(f"Файл {namePDF} удален\n")


if __name__=="__main__":
    parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2024.pdf')
    parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_12_2016.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_01_2025.pdf')
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_05_2023.pdf')                  ##    пандас не видит текст
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/byulleten_rorf_09_2023.pdf')                  ##    в таблице воздух 14 столбцов, а не 16
    # parsingPDF('https://www.rpatyphoon.ru/upload/medialibrary/spravki/spravka_05_2013.pdf')
        