import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT


def createDB():
    db_name = "typhoon_411" 
    db_params_1 = {
        "host": "localhost",
        "database": "postgres", 
        "user": "postgres",
        "password": "12345"
    }
    db_params_2 = {
        "host": "localhost",
        "database": "typhoon_411", 
        "user": "postgres",
        "password": "12345"
    }

    commands = (
        """
        CREATE TABLE IF NOT EXISTS city (
            id SERIAL PRIMARY KEY,
            name VARCHAR(50),
            latitude real,
            longitude real
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS month (
            id SERIAL PRIMARY KEY,
            id_city INTEGER REFERENCES city(id),
            date_1 DATE,
            days_1 INTEGER,
            max_1 real,
            avg_1 real,
            date_2 DATE,
            days_2 INTEGER,
            max_2 real,
            avg_2 real
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS air (
            id SERIAL PRIMARY KEY,
            id_city INTEGER REFERENCES city(id),
            date_1 DATE,
            days_1 INTEGER,
            max_1 real,
            avg_1 real,
            measur_1 INTEGER,
            date_2 DATE,
            days_2 INTEGER,
            max_2 real,
            avg_2 real,
            measur_2 INTEGER
        )
        """
    )

    try:
        conn = psycopg2.connect(**db_params_1)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur = conn.cursor()

        # Проверяем, существует ли база
        cur.execute(f"SELECT 1 FROM pg_database WHERE datname = '{db_name}'")
        exists = cur.fetchone()

        if not exists:
            cur.execute(f'CREATE DATABASE "{db_name}"')
            print(f"База данных '{db_name}' успешно создана.")

        else:
            print(f"База данных '{db_name}' уже существует.")

    except Exception as e:
        print(f"Ошибка при проверке/создании БД: {e}")
    finally:
        if conn:
            cur.close()
            conn.close()

    conn = psycopg2.connect(**db_params_2)
    cur = conn.cursor()
    for com in commands:
        cur.execute(com)
    conn.commit()
    cur.close()
    conn.close()

if __name__=="__main__":
    createDB()