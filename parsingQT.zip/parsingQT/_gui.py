import sys
from ui import Ui_Form
from PyQt6 import QtWidgets
import psycopg2
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np

class TyphoonApp(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)


        self.obj = {
            'city': self.load_city,
            'air': self.load_air,
            'month': self.load_month
        }
        self.abc = {
                        'id': 'id', 
                        'name': 'Город', 
                        'id_city': 'ID Города',
                        'latitude': 'Долгота', 
                        'longitude': 'Широта',
                        'date_1': 'Дата 1',
                        'days_1': 'Число\nдней до\nизмер. 1', 
                        'max_1': 'Максим.\nзначение 1', 
                        'avg_1': 'Среднее\nзначение 1', 
                        'measur_1': 'Число\nизмер 1', 
                        'date_2': 'Дата 2',
                        'days_2': 'Число\nдней до\nизмер. 2', 
                        'max_2': 'Максим.\nзначение 2', 
                        'avg_2': 'Среднее\nзначение 2', 
                        'measur_2': 'Число\nизмер 2',
                    }
        self.current_table = ''

        self.ui.tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.ui.tableWidget.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)

        self.db_params = {
            "host": "localhost",
            "database": "typhoon_411",
            "user": "postgres",
            "password": "12345"
        }

        self.ui.bCity.clicked.connect(self.load_city)
        self.ui.bMonth.clicked.connect(self.load_month)
        self.ui.bAir.clicked.connect(self.load_air)
        self.ui.close.clicked.connect(self.close)
        self.ui.deletee.clicked.connect(self.delete_row)
        self.ui.add.clicked.connect(self.add_row)
        self.ui.change.clicked.connect(self.edit_row)
        self.ui.tableWidget.itemDelegate().closeEditor.connect(self.on_editor_closed)
        self.ui.pushButton.clicked.connect(self.build_graph)
        self.fill_filters()

        self.ui.year.setEditable(True)
        self.ui.year.setInsertPolicy(QtWidgets.QComboBox.InsertPolicy.NoInsert)
        self.ui.year.completer().setCompletionMode(QtWidgets.QCompleter.CompletionMode.PopupCompletion)
        self.ui.year.completer().setFilterMode(Qt.MatchFlag.MatchContains)

        self.ui.month.setEditable(True)
        self.ui.month.setInsertPolicy(QtWidgets.QComboBox.InsertPolicy.NoInsert)
        self.ui.month.completer().setCompletionMode(QtWidgets.QCompleter.CompletionMode.PopupCompletion)
        self.ui.month.completer().setFilterMode(Qt.MatchFlag.MatchContains)

        self.ui.city.setEditable(True)
        self.ui.city.setInsertPolicy(QtWidgets.QComboBox.InsertPolicy.NoInsert)
        self.ui.city.completer().setCompletionMode(QtWidgets.QCompleter.CompletionMode.PopupCompletion)
        self.ui.city.completer().setFilterMode(Qt.MatchFlag.MatchContains)


    def names_col_rus(self, names):
        num_columns = []
        for i  in names:
            num_columns.append(self.abc[i])
        return num_columns
    
    def fill_filters(self):
        try:
            with psycopg2.connect(**self.db_params) as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT DISTINCT EXTRACT(YEAR FROM date_1)::int FROM air ORDER BY 1 DESC")
                    years = cur.fetchall()
                    
                    self.ui.year.clear()
                    if years:
                        year_list = [str(y[0]) for y in years if y[0] is not None]
                        self.ui.year.addItems(year_list)
                    else:
                        self.ui.year.addItem("Нет данных")

                    cur.execute("SELECT name FROM city ORDER BY name")
                    cities = [c[0] for c in cur.fetchall()]
                    self.ui.city.clear()
                    self.ui.city.addItems(cities)
                    self.ui.city.setCurrentIndex(-1)
                    self.ui.city.setEditText('')

                    months = [
                        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
                    ]
                    self.ui.month.clear()
                    self.ui.month.addItems(months)
                    
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Ошибка фильтров", f"Не удалось загрузить годы: {e}")

    def build_graph(self):
        selected_year = self.ui.year.currentText()
        selected_month_idx = self.ui.month.currentIndex() + 1
        selected_month_name = self.ui.month.currentText()

        if not self.current_table or self.current_table == 'city' or selected_year == "Нет данных":
            return QtWidgets.QMessageBox.warning(self, "Внимание", "Выберите таблицу (Воздух/Месяц) и год!")

        try:
            with psycopg2.connect(**self.db_params) as conn:
                with conn.cursor() as cur:
                    cur.execute(f"""
                        SELECT column_name FROM information_schema.columns 
                        WHERE table_name = '{self.current_table}' 
                        AND data_type IN ('integer', 'numeric', 'double precision', 'real')
                        AND column_name NOT IN ('id', 'id_city')
                    """)
                    num_columns_eng = [row[0] for row in cur.fetchall()]
                    num_columns = self.names_col_rus(num_columns_eng)

                    avg_fields = ", ".join([f"AVG(t.{col})" for col in num_columns_eng])
                    
                    query = f"""
                        SELECT {avg_fields} 
                        FROM {self.current_table} t
                        JOIN city c ON t.id_city = c.id
                        WHERE EXTRACT(YEAR FROM t.date_1) = %s 
                        AND EXTRACT(MONTH FROM t.date_1) = %s
                    """
                    
                    params = [selected_year, selected_month_idx]
                    
                    selected_city = self.ui.city.currentText().strip()
                    if selected_city and selected_city != "":
                        query += " AND c.name = %s"
                        params.append(selected_city)
                    
                    cur.execute(query, tuple(params))
                    avg_values = cur.fetchone()

            if not avg_values or all(v is None for v in avg_values):
                return QtWidgets.QMessageBox.information(self, "Инфо", f"Нет данных за {selected_month_name} {selected_year}")

            fig = Figure(figsize=(7, 4))
            ax = fig.add_subplot(111)
            
            final_values = [float(v) if v is not None else 0 for v in avg_values]
            x_positions = range(len(num_columns))
            
            colors = plt.cm.tab10(np.linspace(0, 1, len(num_columns)))
            
            for i, (val, col_name) in enumerate(zip(final_values, num_columns)):
                ax.bar(x_positions[i], val, color=colors[i], label=col_name, edgecolor='black', alpha=0.8)
            
            ax.set_xticks(x_positions)
            ax.set_xticklabels(num_columns, rotation=25, ha='right')
            ax.set_title(f"Средние показатели: {selected_month_name} {selected_year}")
            ax.tick_params(axis='both', labelsize=8) 
            ax.set_ylabel("Значение")
            ax.grid(True, axis='y', linestyle='--', alpha=0.5)

            ax.legend(title="Показатели", loc='upper left', bbox_to_anchor=(1, 1), fontsize=8)
            
            for i, v in enumerate(final_values):
                ax.text(i, v, f'{v:.2f}', va='bottom', ha='center', fontsize=9, fontweight='bold')

            fig.tight_layout()

            canvas = FigureCanvas(fig)
            scene = QtWidgets.QGraphicsScene()
            scene.addWidget(canvas)
            self.ui.graphicsView.setScene(scene)

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Не удалось построить график: {e}")





    def load_city(self):
        with psycopg2.connect(**self.db_params) as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT * FROM city")
                data = cur.fetchall()
                col_names = [desc[0] for desc in cur.description]
                self.display_data(data, col_names)
        self.current_table = 'city'

    def load_air(self):
        with psycopg2.connect(**self.db_params) as conn:
            with conn.cursor() as cur:
                cur.execute(f'''
                            select 
                                a.id, name, date_1, days_1, max_1, avg_1, measur_1, 
                                date_2, days_2, max_2, avg_2, measur_2
                            from air a
                                join city c on c.id = a.id_city
                            --order by 2;
                            ''')
                data = cur.fetchall()
                col_names = [desc[0] for desc in cur.description]
                self.display_data(data, col_names)
        self.current_table = 'air'
    
    def load_month(self):
        with psycopg2.connect(**self.db_params) as conn:
            with conn.cursor() as cur:
                cur.execute(f'''
                            select 
                                m.id, name, date_1, days_1, max_1, avg_1,
                                date_2, days_2, max_2, avg_2
                            from month m
                                join city c on c.id = m.id_city
                            --order by 2;
                            ''')
                data = cur.fetchall()
                col_names = [desc[0] for desc in cur.description]
                self.display_data(data, col_names)
        self.current_table = 'month'

    def display_data(self, data, columnsEng):
        columns = self.names_col_rus(columnsEng)
        self.ui.tableWidget.setRowCount(len(data))
        self.ui.tableWidget.setColumnCount(len(columns))
        self.ui.tableWidget.setHorizontalHeaderLabels(columns)
        self.ui.tableWidget.setColumnHidden(0, True) 

        for row_idx, row_data in enumerate(data):
            for col_idx, value in enumerate(row_data):
                val = "" if value is None else str(value)
                self.ui.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(val))

    def delete_row(self):
        row = self.ui.tableWidget.currentRow()
        if row < 0:
            return QtWidgets.QMessageBox.warning(self, "Внимание", "Выберите строку для удаления")
        id_to_delete = self.ui.tableWidget.item(row, 0).text()
        confirm = QtWidgets.QMessageBox.question(self, "Подтверждение", 
                                               f"Удалить запись с ID {id_to_delete} из таблицы {self.current_table}?")
        if confirm == QtWidgets.QMessageBox.StandardButton.Yes:
            try:
                with psycopg2.connect(**self.db_params) as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"DELETE FROM {self.current_table} WHERE id = %s", (id_to_delete,))
                    conn.commit()
                self.obj[self.current_table]()
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "Ошибка", f"Не удалось удалить: {e}")

    def add_row(self):
        if not self.current_table:
            return QtWidgets.QMessageBox.warning(self, "Ошибка", "Сначала выберите таблицу!")

        try:
            new_id = None
            if self.current_table == 'city':
                with psycopg2.connect(**self.db_params) as conn:
                    with conn.cursor() as cur:
                        cur.execute("INSERT INTO city (name, latitude, longitude) VALUES ('Новый город', 0, 0) RETURNING id")
                        new_id = cur.fetchone()[0]
            
            elif self.current_table in ['air', 'month']:
                with psycopg2.connect(**self.db_params) as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT id, name FROM city ORDER BY name")
                        cities = cur.fetchall()
                
                if not cities:
                    return QtWidgets.QMessageBox.warning(self, "Ошибка", "Сначала добавьте хотя бы один город!")

                dialog = QtWidgets.QDialog(self)
                dialog.setWindowTitle("Выбор города")
                layout = QtWidgets.QVBoxLayout(dialog)
                
                label = QtWidgets.QLabel("Выберите город для новой записи:")
                combo = QtWidgets.QComboBox()
                for c_id, c_name in cities:
                    combo.addItem(c_name, c_id)

                combo.setEditable(True)
                combo.setCurrentIndex(-1)
                combo.setInsertPolicy(QtWidgets.QComboBox.InsertPolicy.NoInsert)
                combo.completer().setFilterMode(Qt.MatchFlag.MatchContains)
                combo.completer().setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
                
                button_box = QtWidgets.QDialogButtonBox(
                    QtWidgets.QDialogButtonBox.StandardButton.Ok | 
                    QtWidgets.QDialogButtonBox.StandardButton.Cancel
                )
                button_box.accepted.connect(dialog.accept)
                button_box.rejected.connect(dialog.reject)
                
                layout.addWidget(label)
                layout.addWidget(combo)
                layout.addWidget(button_box)

                if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
                    city_id = combo.currentData() 
                    if city_id is None: 
                        return QtWidgets.QMessageBox.warning(self, "Ошибка", "Выберите город из списка!")
                        
                    with psycopg2.connect(**self.db_params) as conn:
                        with conn.cursor() as cur:
                            cur.execute(f"INSERT INTO {self.current_table} (id_city) VALUES (%s) RETURNING id", (city_id,))
                            new_id = cur.fetchone()[0]
                else:
                    return

            self.obj[self.current_table]()
            
            if new_id:
                last_row = self.ui.tableWidget.rowCount() - 1
                self.ui.tableWidget.selectRow(last_row)
                QtWidgets.QMessageBox.information(self, "Успех", f"Добавлена запись с ID {new_id}. Отредактируйте её в таблице.")

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка БД", f"Не удалось добавить строку: {e}")



    def edit_row(self):
        item = self.ui.tableWidget.currentItem()
        if item:
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
            self.ui.tableWidget.editItem(item)
        else:
            QtWidgets.QMessageBox.warning(self, "Внимание", "Выберите ячейку для изменения")

    def save_cell_to_db(self, item):        
        self.ui.tableWidget.blockSignals(True)
        
        row = item.row()
        col = item.column()
        new_value = item.text().strip()
        
        id_item = self.ui.tableWidget.item(row, 0)
        if not id_item or not id_item.text():
            self.ui.tableWidget.blockSignals(False)
            return

        russian_header = self.ui.tableWidget.horizontalHeaderItem(col).text()

        reverse_abc = {v.replace('\n', ' '): k for k, v in self.abc.items()}
        clean_header = russian_header.replace('\n', ' ')
        db_column_name = reverse_abc.get(clean_header)

        if not db_column_name or db_column_name in ['id', 'name']:
            self.ui.tableWidget.blockSignals(False)
            return

        try:
            with psycopg2.connect(**self.db_params) as conn:
                with conn.cursor() as cur:
                    query = f"UPDATE {self.current_table} SET {db_column_name} = %s WHERE id = %s"
                    cur.execute(query, (new_value if new_value != "" else None, id_item.text()))

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Не удалось обновить БД: {e}")
            if self.current_table in self.obj:
                self.obj[self.current_table]() 
        
        self.ui.tableWidget.blockSignals(False)


    def on_editor_closed(self):
        item = self.ui.tableWidget.currentItem()
        if item:
            self.save_cell_to_db(item)





if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = TyphoonApp() 
    window.show()
    sys.exit(app.exec())
